// button hamburger
const menu_btn = document.querySelector('.hamburger');
const nav = document.querySelector('nav ul');

menu_btn.addEventListener('click',function(){
    menu_btn.classList.toggle('is-active');
    nav.classList.toggle('slide');
});

//button serach
const icon_btn = document.querySelector('.icon');
const search = document.querySelector('.search');

icon_btn.addEventListener('click', function(){
    search.classList.toggle("active");
});

feather.replace();